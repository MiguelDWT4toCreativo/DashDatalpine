<?php 
error_reporting(0);   
                include("con_db.php");
                if(isset($_POST['entrar'])){
                    // rescatar obtener los datos de la caja de texto usuario y password de el formulario
                    $usuario = $conex->real_escape_string($_POST['emaill']);
                    $password = $conex->real_escape_string($_POST['contraseña']);
                    // consulta para ingresar al sistema y determinar la variable de session
                    $q = "SELECT * FROM datos WHERE email = '$usuario' and Contraseña = '$password'";
                    // comparo que los datos se encuentren y se guarden en las variables userok y passwordok
                    if($resultado = $conex->query($q)) {
                      while ($row = $resultado->fetch_array()) {
                        $userok = $row['email'];
                        $passwordok = $row['Contraseña'];
                      }
                      $resultado->close();
                    }
                    $conex->close();
                    // comparo datos extraidos con datos de el usuario si son correctos
                    if (strlen($_POST['emaill']) >= 1 && strlen($_POST['contraseña']) >= 1) {
                       if ($usuario == $userok && $password == $passwordok) {
                           $_SESSION['login']= TRUE;
                           header("location:index.html");
                        }
                        else{
                            $mensaje.="<div class='alert alert-danger alert-dismissible fade show shadow-lg p-3 mb-5 bg-white rounded' role='alert'>
                                          <strong>Usuario no valido</strong> El usuario no se encuentra registrado en el sistema consulta a soporte.
                                          <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                                             <span aria-hidden='true'>&times;</span>
                                          </button>
                                        </div>";
                                      }
                        }
                    else {
                            $mensaje.="<div class='alert alert-warning alert-dismissible fade show shadow-lg p-3 mb-5 bg-white rounded' role='alert'>
                            ¡Por favor complete los campos!.
                                          <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                                             <span aria-hidden='true'>&times;</span>
                                          </button>
                                        </div>";
              }
            }
            ?>
<!DOCTYPE html>
<html lang="en"
      dir="ltr">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible"
              content="IE=edge">
        <meta name="viewport"
              content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Login</title>

        <!-- Prevent the demo from appearing in search engines -->
        <meta name="robots"
              content="noindex">

        <!-- Perfect Scrollbar -->
        <link type="text/css"
              href="assets/vendor/perfect-scrollbar.css"
              rel="stylesheet">

        <!-- App CSS -->
        <link type="text/css"
              href="assets/css/app.css"
              rel="stylesheet">
        <link type="text/css"
              href="assets/css/app.rtl.css"
              rel="stylesheet">

        <!-- Material Design Icons -->
        <link type="text/css"
              href="assets/css/vendor-material-icons.css"
              rel="stylesheet">
        <link type="text/css"
              href="assets/css/vendor-material-icons.rtl.css"
              rel="stylesheet">

        <!-- Font Awesome FREE Icons -->
        <link type="text/css"
              href="assets/css/vendor-fontawesome-free.css"
              rel="stylesheet">
        <link type="text/css"
              href="assets/css/vendor-fontawesome-free.rtl.css"
              rel="stylesheet">

        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async
                src="https://www.googletagmanager.com/gtag/js?id=UA-133433427-1"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());
            gtag('config', 'UA-133433427-1');
        </script>

    </head>

    <body class="layout-login">

        <div class="layout-login__overlay"></div>
        <div class="layout-login__form bg-white"
             data-perfect-scrollbar>
            <div class="d-flex justify-content-center mt-2 mb-5 navbar-light">
                <a href="index.html">
                    <img width="230" height="45"src="Logo.png"/>
                </a>
            </div>

            <h4 class="m-0">Bienvenido de vuelta</h4>
            <p class="mb-5">Ingresa tu cuenta para tener acceso a Datalpine  </p>

            <a href=""
               class="btn btn-light btn-block">
                <span class="fab fa-google mr-2"></span>
                Continua con Google
            </a>

            <div class="page-separator">
                <div class="page-separator__text">o</div>
            </div>

            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                <div class="form-group">
                    <label class="text-label"
                           for="email_2">Correo electrónico:</label>
                    <div class="input-group input-group-merge">
                    <input type="email" name="emaill" class="form-control form-control-prepended" placeholder="Email">
                        <div class="input-group-prepend">
                            <div class="input-group-text">
                                <span class="far fa-envelope"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="text-label"
                           for="password_2">Contraseña:</label>
                    <div class="input-group input-group-merge">
                    <input type="password" name="contraseña" class="form-control form-control-prepended" placeholder="Contraseña">
                        <div class="input-group-prepend">
                            <div class="input-group-text">
                                <span class="fa fa-key"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group mb-5">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox"
                               class="custom-control-input"
                               checked=""
                               id="remember">
                        <label class="custom-control-label"
                               for="remember">Recordarme</label>
                    </div>
                </div>
                <div class="form-group text-center">
                    <button class="btn btn-primary mb-5" name="entrar"
                            type="submit">Entrar</button><br>
                    <a href="">¿No recuerdas tu contraseña?</a> <br>
                    ¿No tienes cuenta? <a class="text-body text-underline"
                       href="signup.php">Registrate aqui!</a>
                </div>
            </form>
            
            <?php echo $mensaje; ?>
        </div>

        <!-- jQuery -->
        <script src="assets/vendor/jquery.min.js"></script>

        <!-- Bootstrap -->
        <script src="assets/vendor/popper.min.js"></script>
        <script src="assets/vendor/bootstrap.min.js"></script>

        <!-- Perfect Scrollbar -->
        <script src="assets/vendor/perfect-scrollbar.min.js"></script>

        <!-- DOM Factory -->
        <script src="assets/vendor/dom-factory.js"></script>

        <!-- MDK -->
        <script src="assets/vendor/material-design-kit.js"></script>

        <!-- App -->
        <script src="assets/js/toggle-check-all.js"></script>
        <script src="assets/js/check-selected-row.js"></script>
        <script src="assets/js/dropdown.js"></script>
        <script src="assets/js/sidebar-mini.js"></script>
        <script src="assets/js/app.js"></script>

        <!-- App Settings (safe to remove) -->
        <script src="assets/js/app-settings.js"></script>

    </body>

</html>