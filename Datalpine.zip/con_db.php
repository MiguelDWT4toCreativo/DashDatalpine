<?php

$conex = mysqli_connect("localhost:3306","tocreati_Adgabo","Qj+uxmwXC-H_","Prueba_dash"); 

?>